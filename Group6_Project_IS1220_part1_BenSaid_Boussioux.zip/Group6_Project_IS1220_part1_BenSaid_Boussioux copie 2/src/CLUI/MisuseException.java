package CLUI;

public class MisuseException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9139454639083620032L;

	public MisuseException() {
		super();
	}
	
	public MisuseException(String message) {
		super(message);
	}
}


